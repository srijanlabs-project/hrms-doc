# SDS-004 Color System

Primary: #0F8B8D
Secondary: #E87511
Success: #16A34A
Warning: #F59E0B
Error: #DC2626
Info: #0284C7
