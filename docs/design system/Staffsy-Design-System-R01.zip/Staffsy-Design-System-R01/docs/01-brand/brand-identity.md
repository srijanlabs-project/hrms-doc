# SDS-001 Brand Identity

## Mission
Help organizations build better workplaces through intelligent enterprise software.

## Vision
Become the world's most trusted Enterprise People Platform.

## Personality
Professional, Human, Modern, Intelligent, Calm, Trustworthy.

## Product Naming
- Staffsy
- My Staffsy
- Staffsy Copilot
- Staffsy Insights
- Staffsy Pay
- Staffsy Learn
- Staffsy Hire
