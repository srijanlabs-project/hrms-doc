# SDS-003 Design Principles

1. Clarity before beauty
2. One screen, one purpose
3. Consistency wins
4. Accessibility first
