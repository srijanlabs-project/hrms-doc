# SDS-002 Design Philosophy

Enterprise software should be powerful without feeling complicated.
